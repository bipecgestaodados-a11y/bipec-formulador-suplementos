# BIPEC Gestão de Dados — Formulador de Suplementos para Ruminantes v4.0

Aplicativo web e mobile offline-first desenvolvido com a identidade visual oficial da **BIPEC Gestão de Dados**, reproduzindo integralmente todas as equações, tabelas bromatológicas e relatórios técnicos da planilha `FORMULADOR DE SUPLEMENTOS_RUMINANTES_GUABI_v.4.0.xlsx`.

## Conteúdo do Pacote
- `index.html` (`BIPEC_Formulador_Suplementos_v4.html`): Aplicativo completo autocontido (HTML5 + CSS3 + JS) com o logo original da BIPEC embutido e os **407 ingredientes/produtos** da base carregados nativamente.
- `BIPEC_LOGO.png`: Logo oficial da BIPEC Gestão de Dados (`#001849` Azul Marinho e `#FF2828` Vermelho).
- `base_alimentos_guabi_407.json` / `base_alimentos_guabi_407.csv`: Base bromatológica completa exportada para integração externa.

## Como Publicar ou Usar
1. **Uso Local / Offline (PC ou Android):** Abra o arquivo `index.html` diretamente em qualquer navegador (Chrome, Edge, Safari) ou empacote via WebView/APK no Termux/Android.
2. **GitHub Pages / Netlify:** Faça upload da pasta contendo `index.html` — não exige build nem backend.
